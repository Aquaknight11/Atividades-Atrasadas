Atividade JSON

Nome: Gabriel Costa  
Matrícula: 911268

- Listagem de títulos
- Médias calculadas
- Verificações (some e every)

- O Resumo será exibido na div#output