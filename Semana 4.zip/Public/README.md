Music Library
 
Nome: Gabriel Costa  
Matrícula: 911268
As Propostas são coleções e Itens

É um aplicativo web que apresenta álbuns musicais com suas capas e informações.

