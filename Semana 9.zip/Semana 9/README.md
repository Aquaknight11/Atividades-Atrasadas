Nome: Gabriel Costa  
Matrícula: 911268

A atividade consiste em um Mini Ecommerce, utilizando JavaScript puro (Vanilla JS) para praticar:

- Manipulação de funções
- Uso de JSON (array de objetos)
- Manipulação do DOM
- Eventos de interação com o usuário