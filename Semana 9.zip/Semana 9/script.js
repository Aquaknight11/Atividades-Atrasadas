const data = {
  produtos: [
    { id: 1, nome: "iPhone 13", preco: 4500, categoria: "Celulares", imagem: "https://via.placeholder.com/150", descricao: "iPhone da Apple", emEstoque: true },
    { id: 2, nome: "Galaxy S22", preco: 3800, categoria: "Celulares", imagem: "https://via.placeholder.com/150", descricao: "Samsung top", emEstoque: true },
    { id: 3, nome: "Notebook Dell", preco: 5000, categoria: "Notebooks", imagem: "https://via.placeholder.com/150", descricao: "Notebook potente", emEstoque: false },
    { id: 4, nome: "Mouse Gamer", preco: 150, categoria: "Acessórios", imagem: "https://via.placeholder.com/150", descricao: "Mouse RGB", emEstoque: true },
    { id: 5, nome: "Teclado Mecânico", preco: 300, categoria: "Acessórios", imagem: "https://via.placeholder.com/150", descricao: "Switch azul", emEstoque: true },
    { id: 6, nome: "PlayStation 5", preco: 4500, categoria: "Games", imagem: "https://via.placeholder.com/150", descricao: "Console Sony", emEstoque: false },
    { id: 7, nome: "Xbox Series X", preco: 4300, categoria: "Games", imagem: "https://via.placeholder.com/150", descricao: "Console Microsoft", emEstoque: true },
    { id: 8, nome: "MacBook Air", preco: 7000, categoria: "Notebooks", imagem: "https://via.placeholder.com/150", descricao: "Leve e rápido", emEstoque: true }
  ]
};

const productList = document.getElementById("product-list");
const productDetails = document.getElementById("product-details");

const searchInput = document.querySelector("#search");
const categorySelect = document.querySelector("#category");

function formatPrice(preco) {
  return "R$ " + preco.toFixed(2);
}

function createProductCard(produto) {
  const card = document.createElement("div");
  card.setAttribute("data-id", produto.id);
  card.classList.add("card");

  card.style.backgroundColor = "#f9f9f9";

  const title = document.createElement("h3");
  title.innerText = produto.nome;

  const img = document.createElement("img");
  img.src = produto.imagem;

  const price = document.createElement("p");
  price.innerText = formatPrice(produto.preco);

  const category = document.createElement("p");
  category.innerText = produto.categoria;

  const btnDetails = document.createElement("button");
  btnDetails.innerText = "Ver detalhes";

  const btnHighlight = document.createElement("button");
  btnHighlight.innerText = "Destacar";

  // eventos
  btnDetails.addEventListener("click", () => {
    showProductDetails(produto);
  });

  btnHighlight.addEventListener("click", () => {
    card.classList.toggle("highlight");
  });

  card.appendChild(title);
  card.appendChild(img);
  card.appendChild(price);
  card.appendChild(category);
  card.appendChild(btnDetails);
  card.appendChild(btnHighlight);

  return card;
}

function renderProducts(produtos) {
  productList.innerHTML = "";

  produtos.forEach(produto => {
    const card = createProductCard(produto);
    productList.appendChild(card);
  });

  // querySelectorAll obrigatório
  const cards = document.querySelectorAll(".card");
  cards.forEach(card => {
    console.log(card.getAttribute("data-id"));
  });
}

function renderProducts(produtos) {
  productList.innerHTML = "";

  produtos.forEach(produto => {
    const card = createProductCard(produto);
    productList.appendChild(card);
  });

  // querySelectorAll obrigatório
  const cards = document.querySelectorAll(".card");
  cards.forEach(card => {
    console.log(card.getAttribute("data-id"));
  });
}

function filterProducts() {
  const text = searchInput.value.toLowerCase();
  const category = categorySelect.value;

  return data.produtos.filter(p => {
    const matchName = p.nome.toLowerCase().includes(text);
    const matchCategory = category === "Todas" || p.categoria === category;
    return matchName && matchCategory;
  });
}

searchInput.addEventListener("input", () => {
  renderProducts(filterProducts());
});

categorySelect.addEventListener("change", () => {
  renderProducts(filterProducts());
});

document.getElementById("btnRender").addEventListener("click", () => {
  renderProducts(data.produtos);
});

renderCategories();
renderProducts(data.produtos);