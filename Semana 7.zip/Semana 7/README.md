Simulador de Orçamento Pessoal

Nome: Gabriel Costa  
Matrícula: 911268

Este projeto é um simulador simples de orçamento pessoal feito em JavaScript.

Ele permite:
- Inserir renda
- Inserir despesas
- Calcular saldo final
- Classificar situação financeira

- HTML
- JavaScript

Abra o arquivo Index.html no navegador e após isto utilize o prompt.